export interface IObject {
  equals(object: any): boolean;
}
