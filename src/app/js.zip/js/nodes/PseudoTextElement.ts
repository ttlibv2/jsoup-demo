import { Element } from "./1005_Element";

export class PseudoTextElement extends Element {}